<p style="text-align:justify">ESPFlight Hardware Reference v1.0 is the open hardware reference design for the ESPFlight platform.</p>
<p style="text-align:justify">It provides a tested and validated PCB implementation for building ESP-based drones and is designed to work with ESPFlight Firmware and the ESPFlight Application as part of the ESPFlight v1.0 platform baseline.</p>
<p style="text-align:justify">The project is intended for enthusiasts, students, educators, Makers, developers, engineers, researchers, and independent creators who want to build an ESPFlight-compatible drone, study how the hardware works, experiment with the design, or use it as a starting point for their own hardware.</p>
<p style="text-align:justify">The schematic and PCB may be studied, fabricated, modified, adapted, and extended for different projects, layouts, form factors, and compatible hardware implementations.</p>
<p style="text-align:justify">ESPFlight is an open platform rather than a closed hardware ecosystem. This hardware is therefore provided as a reference design, not as an official ESPFlight commercial product or kit.</p>
<p style="text-align:justify">Builders and developers are encouraged to create their own ESPFlight-compatible boards, educational hardware, kits, and independent products based on the platform, subject to the applicable license. Independent products should use their own names and branding and must not be presented as official ESPFlight products.</p>
<p style="text-align:justify">ESPFlight Hardware Reference v1.0 has been developed and tested together with ESPFlight Firmware and the ESPFlight Application to provide a practical, understandable, and reproducible foundation for building and experimenting with ESP-based drone systems.</p>
<p style="text-align:justify">Before building or modifying the design, review the latest documentation, component requirements, assembly information, firmware compatibility, safety guidance, and project revision.</p>
<p style="text-align:justify">Firmware, documentation, application downloads, build guides, and project updates are available at:</p>
<p style="text-align:justify"><a href="https://espflight.com/" target="_blank">https://espflight.com</a></p>
<p style="text-align:justify">License: CERN Open Hardware Licence Version 2 — Permissive (CERN-OHL-P-2.0).</p>
<p style="text-align:justify">This design may be studied, modified, built upon, and used as the foundation for independent projects and products, subject to the terms of the license.</p>
<p style="text-align:justify">The ESPFlight name, logo, visual identity, and other brand assets are not included in the open hardware license. Independent projects and products must use their own branding and must not imply official endorsement, sponsorship, or affiliation with ESPFlight unless explicitly authorized.</p>
<p style="text-align:justify">Learn it. Build it. Change it. Create your own.</p>            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。